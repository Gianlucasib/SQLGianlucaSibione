CREATE DATABASE if NOT EXISTS LogisticsAnalysis;

USE LogisticsAnalysis;

CREATE TABLE IF NOT EXISTS ExpertiseLevel (
  LevelID INT NOT NULL,
  ExpertiseLevelName VARCHAR(50),
  PRIMARY KEY (LevelID)
);

INSERT INTO ExpertiseLevel (LevelID, ExpertiseLevelName) VALUES 
(1, 'Novice'),
(2, 'Intermediate'),
(3, 'Advanced'),
(4, 'Expert'),
(5, 'Master');

CREATE TABLE IF NOT EXISTS IndustryNames (
  IndustryUniqueID INT NOT NULL,
  IndustryUniqueName VARCHAR(50),
  PRIMARY KEY (IndustryUniqueID)
);

INSERT INTO IndustryNames (IndustryUniqueID, IndustryUniqueName) VALUES 
(11, 'LifeStyle'),
(22, 'Automotive'),
(33, 'Grains&Commodities'),
(44, 'FreightForwarders'),
(55, 'Technology');

CREATE TABLE IF NOT EXISTS `Customer Experience Agent` (
  UniqueAgentID VARCHAR(50),
  CustomerName VARCHAR(50),
  ExpertiseLvl INT,
  Age INT,
  Industry INT,
  PRIMARY KEY (UniqueAgentID),
  FOREIGN KEY (ExpertiseLvl) REFERENCES ExpertiseLevel(LevelID),
  FOREIGN KEY (Industry) REFERENCES IndustryNames(IndustryUniqueID)
);

CREATE TABLE IF NOT EXISTS Customers (
  UniqueCustomerID VARCHAR(50),
  FullCustomerName VARCHAR(100),
  Industry INT,
  Email VARCHAR(50),
  PRIMARY KEY (UniqueCustomerID),
  FOREIGN KEY (Industry) REFERENCES IndustryNames(IndustryUniqueID)
);
CREATE TABLE TypeOfContainerName (
  ContainerUniqueCode INT PRIMARY KEY,
  ContainerName VARCHAR(50),
  ContainerSize VARCHAR(50),
  ContainerType VARCHAR(50),
  ContainerHeight INT
);

CREATE TABLE PlacesOfDestinationChart (
  CountryCodeDestination INT PRIMARY KEY,
  CountryDestinationName VARCHAR(50),
  PortName VARCHAR(50)
);

CREATE TABLE PlacesOfOriginChart (
  CountryCodeOrigin INT PRIMARY KEY,
  CountryOriginName VARCHAR(50),
  PortNameOrigin VARCHAR(50)
);
CREATE TABLE ResponseCategories (
    CategoryUniqueId INT NOT NULL AUTO_INCREMENT,
    CategoryName VARCHAR(50) NOT NULL,
    CategoryScore INT NOT NULL,
    PRIMARY KEY (CategoryUniqueId)
);
CREATE TABLE SatisfactionSurveys (
    SurveyUniqueID INT NOT NULL AUTO_INCREMENT,
    CustomerCode VARCHAR(50),
    Score INT NOT NULL,
    CategoryOfResponse INT NOT NULL,
    PRIMARY KEY (SurveyUniqueID),
    FOREIGN KEY (CustomerCode)
        REFERENCES Customers(UniqueCustomerID),
    FOREIGN KEY (CategoryOfResponse)
        REFERENCES ResponseCategories(CategoryUniqueId)
);


CREATE TABLE TypeOfOperationName (
  OpsCode INT PRIMARY KEY,
  OperationName VARCHAR(50)
);

CREATE TABLE BookedService (
  ServiceUniqueCode INT PRIMARY KEY,
  TransportType VARCHAR(50)
);

CREATE TABLE Bookings (
  BookingNumberCode INT PRIMARY KEY,
  UniqueCustomerID VARCHAR(50),
  TypeOfContainerCode INT,
  ContainerCount INT,
  PlaceOfDestinationCode INT,
  PlaceOfOriginCode INT,
  TypeOfOperationCode INT,
  Date DATE,
  BookedServiceCode INT,
  FOREIGN KEY (UniqueCustomerID) REFERENCES Customers(UniqueCustomerID),
  FOREIGN KEY (TypeOfContainerCode) REFERENCES TypeOfContainerName(ContainerUniqueCode),
  FOREIGN KEY (PlaceOfDestinationCode) REFERENCES PlacesOfDestinationChart(CountryCodeDestination),
  FOREIGN KEY (PlaceOfOriginCode) REFERENCES PlacesOfOriginChart(CountryCodeOrigin),
  FOREIGN KEY (TypeOfOperationCode) REFERENCES TypeOfOperationName(OpsCode),
  FOREIGN KEY (BookedServiceCode) REFERENCES BookedService(ServiceUniqueCode)
);


